export const selectMenu = (data) => ({
    type:"menuSelectedType",
    payload:data
})
