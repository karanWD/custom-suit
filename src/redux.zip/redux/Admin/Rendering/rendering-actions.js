export const rendering = (data)=>({
    type:"RENDERING",
    payload:data
})