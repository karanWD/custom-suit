export const listActionType = {
    FETCH_LIST:"FETCH_LIST",
    DELETE_LIST:"DELETE_LIST"
}