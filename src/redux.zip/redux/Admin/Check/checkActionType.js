export const checkActionType = {
    FETCH_RENDERS : "FETCH_RENDERS"
}