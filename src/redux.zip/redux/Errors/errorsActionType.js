export const errorsActionType = {
    UPLOAD_ERROR : "UPLOAD_ERROR",
    EMPTY_ERROR:"EMPTY_ERROR",
    LOGIN_ERROR:"LOGIN_ERROR",
}