export const loginActionType = {
    LOGIN:"LOGIN",
    SET_EMAIL:"SET_EMAIL",
    SET_PASS:"SET_PASS",
    LOGOUT:"LOGOUT",
}
